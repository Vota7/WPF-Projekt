﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sbirka
{
    public class Soundtracky
    {
        public int ID {  get; set; }
        public string Nazev { get; set; }
        public string Autor { get; set; }
        public int RokVydani { get; set; }
        public string Zanr { get; set; }
        public int KusuSkladem { get; set; }
        public bool KDispozici { get; set; }
    }
}
