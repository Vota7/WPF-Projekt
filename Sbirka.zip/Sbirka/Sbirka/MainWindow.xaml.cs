﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sbirka
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Soundtracky> SoundtrackyList = new()
        {
        };

        public MainWindow()
        {
            InitializeComponent();
            Default();
        }

        public void Default()
        {
            SoundtrackyList.Add(new Soundtracky { ID = 0, Nazev = "Ultrakill: Infinite Hyperdeath", Autor = "Hakita 'Jakito' PITR Patala", RokVydani = 2020, Zanr = "Rock/Metal", KusuSkladem = 0, KDispozici = false});
            SoundtrackyList.Add(new Soundtracky { ID = 1, Nazev = "Risk of Rain 2", Autor = "Chris Christodoulou", RokVydani = 2020, Zanr = "Prog. Rock", KusuSkladem = 3, KDispozici = true });
            SoundtrackyList.Add(new Soundtracky { ID = 1, Nazev = "Good Kid 4", Autor = "Good Kid", RokVydani = 2024, Zanr = "Indie Rock", KusuSkladem = 31, KDispozici = true });
        }

    }
}