﻿using System.Collections.ObjectModel;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sbirka
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ZakladniSoundtracky();
            DataContext = this;
            dgSoundtracky.ItemsSource = ListSoundtracku;
        }

        public int IdJiny;
        public string NazevJiny;
        public string AutorJiny;
        public int RokJiny;
        public string ZanrJiny;
        public int KusuSklademJiny;
        public bool KDispoziciJiny;
        public List<int> roky = Enumerable.Range(1950, 80).ToList();

        public ObservableCollection<Soundtracky> ListSoundtracku = new()
        {

        };
        public void ZakladniSoundtracky()
        {
            ListSoundtracku.Add(new Soundtracky { Nazev = "Ultrakill: Infinite Hyperdeath", Autor = "Heaven Pierce Her", RokVydani = 2020, Zanr = "Rock/Metal", KusuSkladem = 0, KDispozici = false });
            ListSoundtracku.Add(new Soundtracky { Nazev = "Risk of Rain 2", Autor = "Chris Christodoulou", RokVydani = 2020, Zanr = "Prog. Rock", KusuSkladem = 3, KDispozici = true });
            ListSoundtracku.Add(new Soundtracky { Nazev = "Good Kid 4", Autor = "Good Kid", RokVydani = 2024, Zanr = "Indie Rock", KusuSkladem = 31, KDispozici = true });
        }
        public void Button_Click1(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Text1.Text))
            {
                MessageBox.Show("Zadejte platné jméno");
                Text1.Clear();
            }
            else if (string.IsNullOrWhiteSpace(Text2.Text))
            {
                MessageBox.Show("Zadejte platného autora.");
                Text2.Clear();
            }
            else if (string.IsNullOrWhiteSpace(Text3.Text) || int.TryParse(Text3.Text, out var vysledek) == false || !roky.Contains(int.Parse(Text3.Text)))
            {
                MessageBox.Show("Zadejte platný rok.");
                Text3.Clear();
            }
            else if (string.IsNullOrWhiteSpace(Text4.Text))
            {
                MessageBox.Show("Zadejte platný žánr.");
                Text2.Clear();
            }
            else if (string.IsNullOrWhiteSpace(Text5.Text) || int.TryParse(Text5.Text, out var vysledek2) == false || int.Parse(Text5.Text) < 0)
            {
                MessageBox.Show("Zadejte platný počet kusů.");
                Text4.Clear();
            }
            else
            {

                RokJiny = int.Parse(Text3.Text);
                NazevJiny = Text1.Text;
                AutorJiny = Text2.Text;
                ZanrJiny = Text4.Text;
                KusuSklademJiny = int.Parse(Text5.Text);
                if (Check1.IsChecked ?? true) KDispoziciJiny = true;
                else KDispoziciJiny = false;
                ListSoundtracku.Add(new Soundtracky { Nazev = NazevJiny, Autor = AutorJiny, RokVydani = RokJiny, Zanr = ZanrJiny, KusuSkladem = KusuSklademJiny, KDispozici = KDispoziciJiny });
                dgSoundtracky.ItemsSource = ListSoundtracku;
            }
        }
        public void Button_Click2(object sender, RoutedEventArgs e)
        {
            if (dgSoundtracky.SelectedItem is Soundtracky selected)
            {
                Text1.Text = selected.Nazev;
                Text2.Text = selected.Autor;
                Text3.Text = selected.RokVydani.ToString();
                Text4.Text = selected.Zanr;
                Text5.Text = selected.KusuSkladem.ToString();
                if (selected.KDispozici == true) Check1.IsChecked = true;
                else Check1.IsChecked = false;
            }
        }
        public void Button_Click3(object sender, RoutedEventArgs e)
        {
            if (dgSoundtracky.SelectedItem is Soundtracky selected)
            {
                if (string.IsNullOrWhiteSpace(Text1.Text))
                {
                    MessageBox.Show("Zadejte platný název.");
                    Text1.Clear();
                }
                else if (string.IsNullOrWhiteSpace(Text2.Text))
                {
                    MessageBox.Show("Zadejte platného autora.");
                    Text2.Clear();
                }
                else if (string.IsNullOrWhiteSpace(Text3.Text) || int.TryParse(Text3.Text, out var vysledek) == false || !roky.Contains(int.Parse(Text3.Text)))
                {
                    MessageBox.Show("Zadejte platný rok.");
                    Text3.Clear();
                }
                else if (string.IsNullOrWhiteSpace(Text4.Text))
                {
                    MessageBox.Show("Zadejte platný žánr.");
                    Text2.Clear();
                }
                else if (string.IsNullOrWhiteSpace(Text5.Text) || int.TryParse(Text5.Text, out var vysledek2) == false || int.Parse(Text5.Text) < 0)
                {
                    MessageBox.Show("Zadejte platný počet kusů.");
                    Text5.Clear();
                }
                else
                {
                    selected.Nazev = Text1.Text;
                    selected.Autor = Text2.Text;
                    selected.RokVydani = int.Parse(Text3.Text);
                    selected.Zanr = Text4.Text;
                    selected.KusuSkladem = int.Parse(Text5.Text);
                    if (Check1.IsChecked == true) selected.KDispozici = true;
                    else selected.KDispozici = false;
                    dgSoundtracky.Items.Refresh();
                }
            }
        }
        public void Button_Click4(object sender, RoutedEventArgs e)
        {
            if (dgSoundtracky.SelectedItem != null)
            {
                ListSoundtracku.Remove((Soundtracky)dgSoundtracky.SelectedItem);
            }
        }
        public void Button_Click5(object sender, RoutedEventArgs e)
        {
            Text1.Clear();
            Text2.Clear();
            Text3.Clear();
            Text4.Clear();
            Text5.Clear();
            Check1.IsChecked = false;
        }
    }
}