﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sbirka
{
    public partial class MainWindow : Window
    {
        public string text1;
        public string text2;
        public string text3;
        public string text4;
        public string text5;
        public bool text6;

        public ObservableCollection<Soundtracky> SoundtrackyList = new()
        {
        };

        public MainWindow()
        {
            InitializeComponent();
            Default();
            dgSoundtracky.ItemsSource = SoundtrackyList;
        }

        public void Default()
        {
            SoundtrackyList.Add(new Soundtracky { Nazev = "Ultrakill: Infinite Hyperdeath", Autor = "Hakita 'Jakito' PITR Patala", RokVydani = "2020", Zanr = "Rock/Metal", KusuSkladem = "0", KDispozici = false});
            SoundtrackyList.Add(new Soundtracky { Nazev = "Risk of Rain 2", Autor = "Chris Christodoulou", RokVydani = "2020", Zanr = "Prog. Rock", KusuSkladem = "3", KDispozici = true });
            SoundtrackyList.Add(new Soundtracky { Nazev = "Good Kid 4", Autor = "Good Kid", RokVydani = "2024", Zanr = "Indie Rock", KusuSkladem = "31", KDispozici = true });
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            text1 = Text1.Text;
            text2 = Text2.Text;
            text3 = Text3.Text;
            text4 = Text4.Text;
            text5 = Text5.Text;
            if (Check1.IsChecked ?? true) text6 = true;
            else text6 = false;
            SoundtrackyList.Add(new Soundtracky { Nazev = text1, Autor = text2, RokVydani = text3, Zanr = text4, KusuSkladem = text5, KDispozici = text6 });
        }
    }
}