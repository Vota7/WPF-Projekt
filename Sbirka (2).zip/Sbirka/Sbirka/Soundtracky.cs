﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sbirka
{
    public class Soundtracky
    {
        public string Nazev { get; set; }
        public string Autor { get; set; }
        public string RokVydani { get; set; }
        public string Zanr { get; set; }
        public string KusuSkladem { get; set; }
        public bool KDispozici { get; set; }
    }
}
